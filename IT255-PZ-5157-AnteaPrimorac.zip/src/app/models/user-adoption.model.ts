export interface UserAdoption {
    adoptionId: number;
    userId: number;
}
