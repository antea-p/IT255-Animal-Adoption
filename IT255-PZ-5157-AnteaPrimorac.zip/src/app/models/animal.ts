export interface Animal {
  id: number;
  name: string;
  image: string;
  age: string;
  speciesName: string;
  description: string;
  price: number;
}
